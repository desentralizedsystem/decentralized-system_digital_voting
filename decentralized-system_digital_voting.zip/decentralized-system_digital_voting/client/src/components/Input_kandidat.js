import React, { Component } from 'react'



export class Input_kandidat extends Component {
	render() {
		return (
			<div className="col-md-12">
				<div className="col-md-4">
					<h3><b>Input Kandidat</b></h3>
					<form 
						onSubmit={(event) => {
							event.preventDefault()
							const name = this.userName.value
							const nik = this.nik.value
							this.props.createUser(name, nik)
						}}>
						<div className="form-group mr-sm-2">
							<label htmlFor="userName">Nama Kandidat</label>
							<input
							id="userName"
							type="text"
							ref={(input) => { this.userName = input }}
							className="form-control"
							placeholder="Masukkan nama kandidat"
							required />
						</div>
						<div className="form-group mr-sm-2">
							<label htmlFor="nik">No Urut</label>
							<input
							id="nik"
							type="text"
							ref={(input) => { this.nik = input }}
							className="form-control"
							placeholder="Masukkan nomor urut kandidat"
							required />
						</div>
						<button type="submit" className="btn btn-info">Submit</button>
					</form>
				</div>
				<hr className="my-4"/>
				<h5><b>Daftar Kandidat</b></h5>
				<table className="table table-bordered">
					<thead>
						<tr>
							
							<th scope="col">Nama Kandidat</th>
							<th scope="col">No Urut</th>
						</tr>
					</thead>
					<tbody>
						{this.props.users.filter(p => p.owner === this.props.account).length > 0
							? this.props.users
								.filter(p => p.owner === this.props.account)
								.map((user, key) => {
								return (
									<tr key={key}>
										
										<td>{user.name}</td>
										<td>{user.nik}</td>
									</tr>
								)
								})
							: <tr><td colSpan="3" className="text-center">Data tidak tersedia.</td></tr>
						}
					</tbody>
				</table>
			</div>
		)
	}
}

export default Input_kandidat